package main

import "github.com/achannarasappa/ticker/cmd"

func main() {
	cmd.Execute()
}
